#include "TomatoCubeBadgeWorker.h"



// void initTomatoCube() {
TomatoCubeBadgeWorker::TomatoCubeBadgeWorker() {
  
  songTempo = 200;
  wholenote = (60000 * 4) / songTempo;

  // initialize digital pin LED_BUILTIN as an output.
  pinMode(LED_BUILTIN, OUTPUT);
  pinMode(TONE_PINOUT, OUTPUT);
  digitalWrite(TONE_PINOUT, LOW);
  noTone(TONE_PINOUT);
  
  pinMode(LED_1_PINOUT, OUTPUT);
  pinMode(LED_2_PINOUT, OUTPUT);
  pinMode(LED_3_PINOUT, OUTPUT);
  pinMode(LED_4_PINOUT, OUTPUT);
  pinMode(LED_5_PINOUT, OUTPUT);
  pinMode(LED_6_PINOUT, OUTPUT);
  pinMode(LED_7_PINOUT, OUTPUT);

  pinMode(BUTTON_1_PINOUT, INPUT_PULLUP);
  pinMode(BUTTON_2_PINOUT, INPUT_PULLUP);

}


int TomatoCubeBadgeWorker::TomatoCubeBadgeWorker::freqLookup(unsigned char note) {
  switch(note) {
    case NOTE_B0:
        return 31;
        break;
    case NOTE_C1 :
        return 33;
        break;
    case NOTE_CS1 :
        return 35;
        break;
    case NOTE_D1  :
        return 37;
        break;
    case NOTE_DS1 :
        return 39;
        break;
    case NOTE_E1  :
        return 41;
        break;
    case NOTE_F1  :
        return 44;
        break;
    case NOTE_FS1 :
        return 46;
        break;
    case NOTE_G1  :
        return 49;
        break;
    case NOTE_GS1 :
        return 52;
        break;
    case NOTE_A1  :
        return 55;
        break;
    case NOTE_AS1 :
        return 58;
        break;
    case NOTE_B1  :
        return 62;
        break;
    case NOTE_C2  :
        return 65;
        break;
    case NOTE_CS2 :
        return 69;
        break;
    case NOTE_D2  :
        return 73;
        break;
    case NOTE_DS2 :
        return 78;
        break;
    case NOTE_E2  :
        return 82;
        break;
    case NOTE_F2  :
        return 87;
        break;
    case NOTE_FS2 :
        return 93;
        break;
    case NOTE_G2  :
        return 98;
        break;
    case NOTE_GS2 :
        return 104;
        break;
    case NOTE_A2  :
        return 110;
        break;
    case NOTE_AS2 :
        return 117;
        break;
    case NOTE_B2  :
        return 123;
        break;
    case NOTE_C3  :
        return 131;
        break;
    case NOTE_CS3 :
        return 139;
        break;
    case NOTE_D3  :
        return 147;
        break;
    case NOTE_DS3 :
        return 156;
        break;
    case NOTE_E3  :
        return 165;
        break;
    case NOTE_F3  :
        return 175;
        break;
    case NOTE_FS3 :
        return 185;
        break;
    case NOTE_G3  :
        return 196;
        break;
    case NOTE_GS3 :
        return 208;
        break;
    case NOTE_A3  :
        return 220;
        break;
    case NOTE_AS3 :
        return 233;
        break;
    case NOTE_B3  :
        return 247;
        break;
    case NOTE_C4  :
        return 262;
        break;
    case NOTE_CS4 :
        return 277;
        break;
    case NOTE_D4  :
        return 294;
        break;
    case NOTE_DS4 :
        return 311;
        break;
    case NOTE_E4  :
        return 330;
        break;
    case NOTE_F4  :
        return 349;
        break;
    case NOTE_FS4 :
        return 370;
        break;
    case NOTE_G4  :
        return 392;
        break;
    case NOTE_GS4 :
        return 415;
        break;
    case NOTE_A4  :
        return 440;
        break;
    case NOTE_AS4 :
        return 466;
        break;
    case NOTE_B4  :
        return 494;
        break;
    case NOTE_C5  :
        return 523;
        break;
    case NOTE_CS5 :
        return 554;
        break;
    case NOTE_D5  :
        return 587;
        break;
    case NOTE_DS5 :
        return 622;
        break;
    case NOTE_E5  :
        return 659;
        break;
    case NOTE_F5  :
        return 698;
        break;
    case NOTE_FS5 :
        return 740;
        break;
    case NOTE_G5  :
        return 784;
        break;
    case NOTE_GS5 :
        return 831;
        break;
    case NOTE_A5  :
        return 880;
        break;
    case NOTE_AS5 :
        return 932;
        break;
    case NOTE_B5  :
        return 988;
        break;
    case NOTE_C6  :
        return 1047;
        break;
    case NOTE_CS6 :
        return 1109;
        break;
    case NOTE_D6  :
        return 1175;
        break;
    case NOTE_DS6 :
        return 1245;
        break;
    case NOTE_E6  :
        return 1319;
        break;
    case NOTE_F6  :
        return 1397;
        break;
    case NOTE_FS6 :
        return 1480;
        break;
    case NOTE_G6  :
        return 1568;
        break;
    case NOTE_GS6 :
        return 1661;
        break;
    case NOTE_A6  :
        return 1760;
        break;
    case NOTE_AS6 :
        return 1865;
        break;
    case NOTE_B6  :
        return 1976;
        break;
    case NOTE_C7  :
        return 2093;
        break;
    case NOTE_CS7 :
        return 2217;
        break;
    case NOTE_D7  :
        return 2349;
        break;
    case NOTE_DS7 :
        return 2489;
        break;
    case NOTE_E7  :
        return 2637;
        break;
    case NOTE_F7  :
        return 2794;
        break;
    case NOTE_FS7 :
        return 2960;
        break;
    case NOTE_G7  :
        return 3136;
        break;
    case NOTE_GS7 :
        return 3322;
        break;
    case NOTE_A7  :
        return 3520;
        break;
    case NOTE_AS7 :
        return 3729;
        break;
    case NOTE_B7  :
        return 3951;
        break;
    case NOTE_C8  :
        return 4186;
        break;
    case NOTE_CS8 :
        return 4435;
        break;
    case NOTE_D8  :
        return 4699;
        break;
    case REST :
        return 0;
        break;
    default:
        return 5000;
    
  }
}

void TomatoCubeBadgeWorker::adjustTempo(unsigned int _songTempo) {
  songTempo = _songTempo;
  wholenote = (60000 * 4) / songTempo;
}

int TomatoCubeBadgeWorker::getWholeNote() {
  return wholenote;
}

//void playTone(int pinToneOut, unsigned char note, int duration) {
//  unsigned long startMillis = millis();
//  if (note == REST) {
//      while ( (millis() - startMillis) < duration) {
//            digitalWrite(pinToneOut, LOW); 
//      }
//  } 
//  else {
//      int msDelay = 500000/(freqLookup(note));
//      while ( (millis() - startMillis) < duration) {
//            digitalWrite(pinToneOut, HIGH);   // turn the LED on (HIGH is the voltage level)
//            delayMicroseconds(msDelay);                       // wait for a second
//            digitalWrite(pinToneOut, LOW);    // turn the LED off by making the voltage LOW
//            delayMicroseconds(msDelay);  
//      }
//  }
//}
void TomatoCubeBadgeWorker::playTone(int pinToneOut, unsigned char note, int duration) {
  unsigned long startMillis = millis();
  if (note == REST) {
      ::noTone(TONE_PINOUT);
      delay(duration);
  } 
  else {
    ::tone(TONE_PINOUT, freqLookup(note), duration);  
    delay(duration);
  }
}





void TomatoCubeBadgeWorker::sendMusicNotes(unsigned char *musicNotes, int musicSize) {
      songNotes = musicNotes;
      sizeMusic = musicSize;
      sizeMusic /= sizeof(unsigned char);
      sizeMusic /= 2;

      thisNote = 0;
      startToneMillis = 0;
}

void TomatoCubeBadgeWorker::stopMusic() {
    sendMusicNotes(0, 0);
}

int TomatoCubeBadgeWorker::playMusic() {
   if ( (millis() - startToneMillis) < noteDuration) {
        if (toneMsDelay <= 0) 
            noTone(TONE_PINOUT);

        return 1;
   }
   else if ((millis() - startToneMillis) < (noteDuration + (noteDuration * 0.30)) ) {
   // to distinguish the notes, set a minimum time between them.
   // the note's duration + 30% seems to work well:
        noTone(TONE_PINOUT);
        return 1;
   }
   else if (thisNote < sizeMusic) {
//        int noteDuration = 0;
        if (songNotes[(thisNote * 2) + 1] < 128) {
          // regular note, just proceed
          noteDuration = (getWholeNote()) / (songNotes[(thisNote * 2) + 1]);
        } else {// if (songNotes[(thisNote * 2) + 1] < 0) {
          noteDuration = (getWholeNote()) / ((songNotes[(thisNote * 2) + 1]) - 128);
          noteDuration *= 1.5; // increases the duration in half for dotted notes
        }

        startToneMillis = millis();
        toneMsDelay = songNotes[(thisNote * 2)];
        if (toneMsDelay == REST)
            toneMsDelay = 0;
        else 
        {
            toneMsDelay = freqLookup(toneMsDelay);
            ::tone(TONE_PINOUT, toneMsDelay, noteDuration*1000);
        }
//        delay(10);
        thisNote += 1;
        return 1;
    }
    else {
      noTone(TONE_PINOUT);
      digitalWrite(TONE_PINOUT, LOW);
      return 0;
    }
}


void TomatoCubeBadgeWorker::scanButton() {
//        TouchKey_Process();
//        uint8_t touchResult = TouchKey_Get();
//        buttonState = digitalRead(buttonPin);
      
        button1tmp = (button1tmp << 1) | ((digitalRead(BUTTON_1_PINOUT) == LOW) ? 1 : 0);
        button2tmp = (button2tmp << 1) | ((digitalRead(BUTTON_2_PINOUT) == LOW) ? 1 : 0);
      
        button1State = (button1tmp & 0x0F) == 0x0F;  // Current State
        button2State = (button2tmp & 0x0F) == 0x0F;   
        
        button1RFlag = (button1tmp & 0x3F) == 0x07;  // On Press or Rising flag
        button2RFlag = (button2tmp & 0x3F) == 0x07;
        
        button1FFlag = (button1tmp & 0x3F) == 0x38;  // On Press or Rising flag
        button2FFlag = (button2tmp & 0x3F) == 0x38;
}

uint8_t TomatoCubeBadgeWorker::getB1State() {
    return button1State;
}

uint8_t TomatoCubeBadgeWorker::getB2State() {
    return button2State;
}

int8_t TomatoCubeBadgeWorker::getB1Transition() { // 0 - no change, 1, onPress, -1, onRelease
    return button1RFlag? 1: button1FFlag? -1: 0;
}

int8_t TomatoCubeBadgeWorker::getB2Transition() { // 0 - no change, 1, onPress, -1, onRelease
    return button2RFlag? 1: button2FFlag? -1: 0;
}


void TomatoCubeBadgeWorker::pixelLED(unsigned char ledPattern) {
      //PA3, PA2, PA1, PB1, PB0, PA7,PA6
//      PORTB = (PORTB & 0xFC) | ((ledPattern & 0x0C) >> 2);  //0xFC | 0x03
//      PORTA = (PORTA & 0x31) | ((ledPattern & 0x70) >> 3) | ((ledPattern & 0x03) << 6); // 0x31 | 0x0E | 0x60
      digitalWrite(LED_1_PINOUT, bitRead(ledPattern, 0)?HIGH:LOW);
      digitalWrite(LED_2_PINOUT, bitRead(ledPattern, 1)?HIGH:LOW);
      digitalWrite(LED_3_PINOUT, bitRead(ledPattern, 2)?HIGH:LOW);
      digitalWrite(LED_4_PINOUT, bitRead(ledPattern, 3)?HIGH:LOW);
      digitalWrite(LED_5_PINOUT, bitRead(ledPattern, 4)?HIGH:LOW);
      digitalWrite(LED_6_PINOUT, bitRead(ledPattern, 5)?HIGH:LOW);
      digitalWrite(LED_7_PINOUT, bitRead(ledPattern, 6)?HIGH:LOW);
      

}
